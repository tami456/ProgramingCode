#include "Collider.h"

Collider::Collider(TYPE type, int modelId)
{
	type_ = type;
	modelId_ = modelId;
}

Collider::~Collider(void)
{
}
